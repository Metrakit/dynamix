<?php

// Initialize the Models for use in the Dynamix Core
return array(
	'formMap' 			=> new FormMap,
	'input' 			=> new InputView,
	'translation' 		=> new Translation,
	'view' 				=> new Viewr,
);
