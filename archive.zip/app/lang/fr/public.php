<?php

return array(

	//Error 
	"page_moved_or_deleted" 	=> "Cette page a été déplacé ou n'existe plus.",
	"permission_denied"			=> "Vous n'êtes pas authorisé à accéder à cette ressource !",
	"fatal_error"				=> "Erreur système !",

	//CRUD
	'validate'              	=> 'Valider',
	'create'              		=> 'Créer',
	'update' 					=> 'Mettre à jour',

);
