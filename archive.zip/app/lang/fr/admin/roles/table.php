<?php

return array(

	'name'       => 'Nom',
	'users'      => "# de l'Utilisateur",
	'created_at' => 'Créé à',

);
