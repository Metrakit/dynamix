<?php

return array(

	'role_management'    => 'Gestion des Rôles',
	'role_update'        => 'Mettre à jour un Rôle',
	'role_delete'        => 'Supprimer un Rôle',
	'create_a_new_role'  => 'Créer un nouveau Rôle',

);