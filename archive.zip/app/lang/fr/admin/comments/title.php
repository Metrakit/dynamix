<?php

return array(

	'comment_management'    => 'Gestion des avis',
	'comment_update'        => 'Mettre à jour un avis',
	'comment_delete'        => 'Supprimer un avis',
	'create_a_new_comment'  => 'Créer un nouveau avis',

);