<?php

return array(

	'title'      => 'avis',
	'user_id'   => '# de avis',
	'created_at' => 'Créé à',

);
