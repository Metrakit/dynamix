<?php

return array(

	'title'      => 'Titre du Post',
	'comments'   => '# de avis',
	'created_at' => 'Créé à',
	'post_id' => 'ID',

);
