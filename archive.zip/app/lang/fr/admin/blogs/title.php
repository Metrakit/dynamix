<?php

return array(

	'blog_management'    => 'Gestion des Posts',
	'blog_update'        => 'Mettre à jour un Post',
	'blog_delete'        => 'Supprimer un Post',
	'create_a_new_blog'  => 'Créer un nouveau Post',

);