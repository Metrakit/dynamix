<?php

return array(

'lastpost'			=> 'Derniers articles',
'btnallposts'		=> 'Tous les articles',
'postName'			=> 'Article',
'show_post'			=> 'Affichage de l\'article',
'edit_post'			=> 'Modifier l\'article',
'create_post'		=> 'Création d\'article',

'register'			=> 'Inscrit',
'btnallusers'		=> 'Tous les inscrits',

'lastcomment'		=> 'Derniers avis',
'btnallcomments'	=> 'Tous les avis',

'postIndex' => 'Managements des articles',
'dashboard' => 'Interface administrateur'

);
