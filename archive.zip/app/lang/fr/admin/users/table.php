<?php

return array(

	'first_name' => 'Prénom',
	'last_name'  => 'Nom',
	'user_id'  => 'ID',
	'username'  => "Nom d'utilisateur",
	'email'      => 'Email',
	'groups'     => 'Groupes',
	'roles'     => 'Rôles',
	'activated'  => 'Activé',
	'created_at' => 'Créé at',

);
