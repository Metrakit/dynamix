<?php

return array(

	'user_management'    => 'Gestion des Utilisateurs',
	'user_update'        => 'Mettre à jour un Utilisateur',
	'user_delete'        => 'Supprimer un Utilisateur',
	'create_a_new_user'  => 'Créer un New Utilisateur',

);
