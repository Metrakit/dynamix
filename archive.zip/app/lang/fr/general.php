<?php

return array(

	'yes' => 'Oui',
	'no'  => 'Non',
    'must_login' => 'Doit être connecté.'

);
