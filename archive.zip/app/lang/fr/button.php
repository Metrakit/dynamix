<?php

return array(

	'edit'   => 'Éditer',
	'delete' => 'Supprimer'
);
