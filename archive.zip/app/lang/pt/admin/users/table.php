<?php

return array(

	'first_name' => 'Primeiro Nome',
	'last_name'  => 'Último Nome',
	'user_id'    => 'Id do Usuário',
	'username'   => 'Nome de Usuário',
	'email'      => 'Email',
	'groups'     => 'Grupos',
	'roles'      => 'Papeis',
	'activated'  => 'Ativado',
	'created_at' => 'Criado em',

);
