<?php

return array(

	'user_management'    => 'Gerenciamento de usuários',
	'user_update'        => 'Atualização de usuário',
	'create_a_new_user'  => 'Criar um novo usuário',

);
