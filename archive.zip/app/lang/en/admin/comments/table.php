<?php

return array(

	'title'      => 'Comment',
	'user_id'   => '# of Comments',
	'created_at' => 'Created at',

);
