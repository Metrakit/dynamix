<?php

return array(

	'blog_management'    => 'Blog Management',
	'blog_update'        => 'Update a Blog',
	'blog_delete'        => 'Delete a Blog',
	'create_a_new_blog'  => 'Create a New Blog',

);