@foreach($files as $f)
{{var_dump($f->path)}}
@endforeach