<?php

class InputType extends Eloquent {

	public $timestamps = false;
	protected $fillable = ['name', 'i18n_title'];
	
}