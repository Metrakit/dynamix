<?php

class I18nType extends Eloquent{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table   = 'i18n_types';
    public $timestamps = false;

}