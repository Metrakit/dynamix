<?php

class Viewr extends Eloquent{
	
	protected $table = "views";
	protected $fillable = ['path'];

}