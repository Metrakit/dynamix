//Object Master
var Master = function (){
	this.start = function (){

	}
}


var masterClass = new Master();
