<?php 

use \Illuminate\View\FileViewFinder;

class CustomFileViewFinder extends FileViewFinder
{
    
}